package com.smartparking.timer.data

import androidx.lifecycle.LiveData
import androidx.room.*

@Dao
interface ParkingDao {
    @Query("SELECT * FROM parking_records ORDER BY startTime DESC")
    fun getAllParkingRecords(): LiveData<List<ParkingEntity>>

    @Insert
    suspend fun insertParkingRecord(parking: ParkingEntity)

    @Update
    suspend fun updateParkingRecord(parking: ParkingEntity)

    @Delete
    suspend fun deleteParkingRecord(parking: ParkingEntity)

    @Query("DELETE FROM parking_records")
    suspend fun deleteAllRecords()

    @Query("SELECT COUNT(*) FROM parking_records")
    suspend fun getRecordCount(): Int

    @Query("SELECT * FROM parking_records WHERE id = :id")
    suspend fun getParkingById(id: Long): ParkingEntity?
}
