package com.smartparking.timer.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import com.smartparking.timer.data.ParkingDatabase
import com.smartparking.timer.data.ParkingEntity
import com.smartparking.timer.repository.ParkingRepository
import kotlinx.coroutines.launch

class ParkingViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: ParkingRepository
    val allParkingRecords: LiveData<List<ParkingEntity>>

    init {
        val parkingDao = ParkingDatabase.getDatabase(application).parkingDao()
        repository = ParkingRepository(parkingDao)
        allParkingRecords = repository.getAllParkingRecords()
    }

    fun insertParkingRecord(parking: ParkingEntity) = viewModelScope.launch {
        repository.insertParkingRecord(parking)
    }

    fun updateParkingRecord(parking: ParkingEntity) = viewModelScope.launch {
        repository.updateParkingRecord(parking)
    }

    fun delete(parking: ParkingEntity) = viewModelScope.launch {
        repository.deleteParkingRecord(parking)
    }

    fun deleteParkingRecord(parking: ParkingEntity) = viewModelScope.launch {
        repository.deleteParkingRecord(parking)
    }

    fun deleteAllRecords() = viewModelScope.launch {
        repository.deleteAllRecords()
    }

    suspend fun getParkingById(id: Long): ParkingEntity? {
        return repository.getParkingById(id)
    }

    fun calculateCost(duration: Long, vehicleType: String): Int {
        val hours = Math.ceil(duration / 3600000.0).toInt()
        return when (vehicleType.lowercase()) {
            "motor" -> hours * 2000
            "mobil" -> hours * 5000
            else -> hours * 2000
        }
    }

    fun formatDuration(duration: Long): String {
        val hours = duration / 3600000
        val minutes = (duration % 3600000) / 60000
        val seconds = (duration % 60000) / 1000
        return String.format("%02d:%02d:%02d", hours, minutes, seconds)
    }
}
