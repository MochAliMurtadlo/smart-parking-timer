package com.smartparking.timer.ui

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.appcompat.widget.SearchView
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.smartparking.timer.R
import com.smartparking.timer.adapter.ParkingHistoryAdapter
import com.smartparking.timer.data.ParkingEntity
import com.smartparking.timer.databinding.ActivityHistoryBinding
import com.smartparking.timer.viewmodel.ParkingViewModel
import java.text.NumberFormat

class HistoryActivity : AppCompatActivity() {
    private lateinit var binding: ActivityHistoryBinding
    private lateinit var parkingViewModel: ParkingViewModel
    private lateinit var historyAdapter: ParkingHistoryAdapter
    private var allRecords = listOf<ParkingEntity>()
    private var currentFilter = "ALL" // ALL, MOTOR, MOBIL

    override fun onCreate(savedInstanceState: Bundle?) {
        // Apply tema sebelum setContentView
        applyThemeFromSettings()
        
        super.onCreate(savedInstanceState)
        binding = ActivityHistoryBinding.inflate(layoutInflater)
        setContentView(binding.root)

        parkingViewModel = ViewModelProvider(this)[ParkingViewModel::class.java]

        setupToolbar()
        setupRecyclerView()
        setupClickListeners()
        observeData()
    }
    
    private fun applyThemeFromSettings() {
        val prefs = getSharedPreferences("parking_settings", MODE_PRIVATE)
        val themeMode = prefs.getString("theme_mode", "system") ?: "system"
        when(themeMode) {
            "light" -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
            "dark" -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
            else -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
        }
    }

    private fun setupToolbar() {
        try {
            setSupportActionBar(binding.toolbar)
            supportActionBar?.apply {
                title = "Riwayat Parkir"
                setDisplayHomeAsUpEnabled(true)
            }
        } catch (e: Exception) {
            // Jika error, set title manual
            binding.toolbar.title = "Riwayat Parkir"
            binding.toolbar.setNavigationOnClickListener {
                onBackPressedDispatcher.onBackPressed()
            }
        }
    }

    private fun setupRecyclerView() {
        historyAdapter = ParkingHistoryAdapter(
            onItemClick = { parking -> showParkingDetail(parking) },
            onDeleteClick = { parking -> showDeleteConfirmation(parking) },
            onFinishClick = { parking -> finishActiveParking(parking) },
            onContinueClick = { parking -> continueActiveParking(parking) }
        )

        binding.recyclerViewHistory.apply {
            adapter = historyAdapter
            layoutManager = LinearLayoutManager(this@HistoryActivity)
            addItemDecoration(DividerItemDecoration(context, DividerItemDecoration.VERTICAL))
        }
    }

    private fun setupClickListeners() {
        binding.fabClearHistory.setOnClickListener {
            showClearHistoryConfirmation()
        }

        binding.btnExportHistory.setOnClickListener {
            exportHistoryToCSV()
        }

        // Chip filters - akan diaktifkan jika layout sudah ada
        try {
            binding.chipAll.setOnClickListener {
                currentFilter = "ALL"
                filterRecords()
            }

            binding.chipMotor.setOnClickListener {
                currentFilter = "MOTOR"
                filterRecords()
            }

            binding.chipMobil.setOnClickListener {
                currentFilter = "MOBIL"
                filterRecords()
            }
        } catch (e: Exception) {
            // Chip belum ada di layout
        }
    }

    private fun observeData() {
        parkingViewModel.allParkingRecords.observe(this) { records ->
            allRecords = records
            filterRecords()

            if (records.isEmpty()) {
                binding.layoutEmpty.visibility = View.VISIBLE
                binding.recyclerViewHistory.visibility = View.GONE
                binding.layoutStats.visibility = View.GONE
                try { binding.chipGroup.visibility = View.GONE } catch (e: Exception) {}
            } else {
                binding.layoutEmpty.visibility = View.GONE
                binding.recyclerViewHistory.visibility = View.VISIBLE
                binding.layoutStats.visibility = View.VISIBLE
                try { binding.chipGroup.visibility = View.VISIBLE } catch (e: Exception) {}

                // Update statistik
                updateStatistics(records)
            }
        }
    }

    private fun updateStatistics(records: List<ParkingEntity>) {
        val totalCost = records.sumOf { it.cost }
        val totalDuration = records.sumOf { it.duration }
        val avgDuration = if (records.isNotEmpty()) totalDuration / records.size else 0L

        binding.apply {
            tvTotalRecords.text = "Total: ${records.size} kali"
            tvTotalCost.text = "Total Biaya: Rp ${NumberFormat.getInstance().format(totalCost)}"
            tvAvgDuration.text = "Rata-rata: ${formatDuration(avgDuration)}"
        }
    }

    private fun showParkingDetail(parking: ParkingEntity) {
        val intent = Intent(this, ResultActivity::class.java).apply {
            putExtra("plate_number", parking.plateNumber)
            putExtra("vehicle_type", parking.vehicleType)
            putExtra("start_time", parking.startTime)
            putExtra("end_time", parking.endTime)
            putExtra("duration", parking.duration)
            putExtra("cost", parking.cost)
            putExtra("from_history", true)
        }
        startActivity(intent)
    }

    private fun showClearHistoryConfirmation() {
        MaterialAlertDialogBuilder(this)
            .setTitle("Hapus Semua Riwayat")
            .setMessage("Apakah Anda yakin ingin menghapus semua riwayat parkir?")
            .setPositiveButton("Hapus") { _, _ ->
                parkingViewModel.deleteAllRecords()
                Toast.makeText(this, "Riwayat berhasil dihapus", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun filterRecords() {
        val filteredList = when (currentFilter) {
            "MOTOR" -> allRecords.filter { it.vehicleType == "Motor" }
            "MOBIL" -> allRecords.filter { it.vehicleType == "Mobil" }
            else -> allRecords
        }
        historyAdapter.submitList(filteredList)
        
        // Update chip selection jika ada
        try {
            binding.chipAll.isChecked = currentFilter == "ALL"
            binding.chipMotor.isChecked = currentFilter == "MOTOR"
            binding.chipMobil.isChecked = currentFilter == "MOBIL"
        } catch (e: Exception) {
            // Chip belum ada
        }
    }

    private fun searchRecords(query: String) {
        val searchList = allRecords.filter {
            it.plateNumber.contains(query, ignoreCase = true)
        }
        historyAdapter.submitList(searchList)
    }

    private fun showDeleteConfirmation(parking: ParkingEntity) {
        MaterialAlertDialogBuilder(this)
            .setTitle("Hapus Riwayat")
            .setMessage("Hapus riwayat parkir ${parking.plateNumber}?")
            .setPositiveButton("Hapus") { _, _ ->
                parkingViewModel.delete(parking)
                Toast.makeText(this, "Riwayat dihapus", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun exportHistoryToCSV() {
        try {
            val csvData = StringBuilder()
            csvData.append("Plat Nomor,Jenis,Mulai,Selesai,Durasi,Biaya\n")
            
            allRecords.forEach { parking ->
                csvData.append("${parking.plateNumber},")
                csvData.append("${parking.vehicleType},")
                csvData.append("${formatDateTime(parking.startTime)},")
                csvData.append("${formatDateTime(parking.endTime)},")
                csvData.append("${formatDuration(parking.duration)},")
                csvData.append("Rp ${parking.cost}\n")
            }
            
            // Share CSV content
            val shareIntent = Intent().apply {
                action = Intent.ACTION_SEND
                putExtra(Intent.EXTRA_TEXT, csvData.toString())
                putExtra(Intent.EXTRA_SUBJECT, "Riwayat Parkir - Smart Parking Timer")
                type = "text/plain"
            }
            startActivity(Intent.createChooser(shareIntent, "Export Riwayat"))
        } catch (e: Exception) {
            Toast.makeText(this, "Gagal export: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun formatDateTime(timestamp: Long): String {
        return java.text.SimpleDateFormat("dd/MM/yyyy HH:mm", java.util.Locale.getDefault())
            .format(java.util.Date(timestamp))
    }

    private fun formatDuration(duration: Long): String {
        val hours = duration / 3600000
        val minutes = (duration % 3600000) / 60000
        return "${hours}j ${minutes}m"
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_history, menu)
        
        val searchItem = menu?.findItem(R.id.action_search)
        val searchView = searchItem?.actionView as? SearchView
        searchView?.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                return false
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                if (newText.isNullOrEmpty()) {
                    filterRecords()
                } else {
                    searchRecords(newText)
                }
                return true
            }
        })
        return true
    }

    private fun finishActiveParking(parking: ParkingEntity) {
        MaterialAlertDialogBuilder(this)
            .setTitle("Selesai Parkir")
            .setMessage("Apakah Anda yakin ingin menyelesaikan parkir ${parking.plateNumber}?")
            .setPositiveButton("Selesai") { _, _ ->
                // Hitung durasi dan biaya final
                val endTime = System.currentTimeMillis()
                val finalDuration = endTime - parking.startTime
                val finalCost = calculateCost(finalDuration, parking.vehicleType)
                
                // Update record
                val updatedParking = parking.copy(
                    endTime = endTime,
                    duration = finalDuration,
                    cost = finalCost,
                    isActive = false
                )
                
                parkingViewModel.updateParkingRecord(updatedParking)
                
                // Clear active session jika ada
                val prefs = getSharedPreferences("parking_session", MODE_PRIVATE)
                val activePlate = prefs.getString("plate_number", "")
                if (activePlate == parking.plateNumber) {
                    prefs.edit().clear().apply()
                }
                
                Toast.makeText(this, "Parkir selesai! Total: Rp $finalCost", Toast.LENGTH_LONG).show()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun continueActiveParking(parking: ParkingEntity) {
        // Set sebagai active session
        val prefs = getSharedPreferences("parking_session", MODE_PRIVATE)
        prefs.edit().apply {
            putBoolean("has_active_session", true)
            putString("plate_number", parking.plateNumber)
            putString("vehicle_type", parking.vehicleType)
            putLong("start_time", parking.startTime)
            putBoolean("is_paused", false)
            apply()
        }
        
        // Buka TimerActivity
        val intent = Intent(this, TimerActivity::class.java)
        startActivity(intent)
    }

    private fun calculateCost(duration: Long, vehicleType: String): Int {
        val hours = Math.ceil(duration / 3600000.0).toInt()
        val prefs = getSharedPreferences("parking_settings", MODE_PRIVATE)
        val motorRate = prefs.getInt("motor_rate", 2000)
        val carRate = prefs.getInt("car_rate", 5000)
        return when (vehicleType.lowercase()) {
            "motor" -> hours * motorRate
            "mobil" -> hours * carRate
            else -> hours * motorRate
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressedDispatcher.onBackPressed()
        return true
    }
}
