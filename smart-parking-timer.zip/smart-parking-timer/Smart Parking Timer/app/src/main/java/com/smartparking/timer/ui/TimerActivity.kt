package com.smartparking.timer.ui

import android.app.*
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.CountDownTimer
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.app.NotificationCompat
import androidx.lifecycle.ViewModelProvider
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.smartparking.timer.R
import com.smartparking.timer.data.ParkingEntity
import com.smartparking.timer.databinding.ActivityTimerBinding
import com.smartparking.timer.viewmodel.ParkingViewModel
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*

class TimerActivity : AppCompatActivity() {
    private lateinit var binding: ActivityTimerBinding
    private lateinit var parkingViewModel: ParkingViewModel

    private var startTime: Long = 0
    private var timer: CountDownTimer? = null
    private var plateNumber: String = ""
    private var vehicleType: String = ""
    private var isPaused = false

    companion object {
        private const val PREFS_NAME = "parking_session"
        private const val KEY_ACTIVE = "has_active_session"
        private const val KEY_PLATE = "plate_number"
        private const val KEY_VEHICLE = "vehicle_type"
        private const val KEY_START_TIME = "start_time"
        private const val KEY_PAUSED = "is_paused"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        // Apply tema sebelum setContentView
        applyThemeFromSettings()
        
        super.onCreate(savedInstanceState)
        binding = ActivityTimerBinding.inflate(layoutInflater)
        setContentView(binding.root)

        parkingViewModel = ViewModelProvider(this)[ParkingViewModel::class.java]

        // Check if there's an active session
        if (!loadActiveSession()) {
            getIntentData()
        }
        
        setupUI()
        startTimer()
        setupClickListeners()
        scheduleNotification()
        createNotificationChannel()
    }

    private fun getIntentData() {
        plateNumber = intent.getStringExtra("plate_number") ?: ""
        vehicleType = intent.getStringExtra("vehicle_type") ?: ""
        startTime = intent.getLongExtra("start_time", System.currentTimeMillis())
    }

    private fun saveActiveSession() {
        val prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
        prefs.edit().apply {
            putBoolean(KEY_ACTIVE, true)
            putString(KEY_PLATE, plateNumber)
            putString(KEY_VEHICLE, vehicleType)
            putLong(KEY_START_TIME, startTime)
            putBoolean(KEY_PAUSED, isPaused)
            apply()
        }
    }

    private fun loadActiveSession(): Boolean {
        val prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
        val hasActiveSession = prefs.getBoolean(KEY_ACTIVE, false)
        
        if (hasActiveSession) {
            plateNumber = prefs.getString(KEY_PLATE, "") ?: ""
            vehicleType = prefs.getString(KEY_VEHICLE, "") ?: ""
            startTime = prefs.getLong(KEY_START_TIME, System.currentTimeMillis())
            isPaused = prefs.getBoolean(KEY_PAUSED, false)
            return true
        }
        return false
    }

    private fun clearActiveSession() {
        val prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
        prefs.edit().clear().apply()
    }

    private fun setupUI() {
        binding.apply {
            tvPlateNumber.text = plateNumber
            tvVehicleType.text = vehicleType
            tvStartTime.text = "Masuk: ${formatTime(startTime)}"

            // Set icon berdasarkan jenis kendaraan
            val iconRes = if (vehicleType == "Motor")
                R.drawable.ic_motorcycle else R.drawable.ic_car
            ivVehicleIcon.setImageResource(iconRes)
        }
    }

    private fun startTimer() {
        timer = object : CountDownTimer(Long.MAX_VALUE, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                if (!isPaused) {
                    val elapsed = System.currentTimeMillis() - startTime
                    updateTimerDisplay(elapsed)
                    updateCostEstimate(elapsed)
                }
            }
            override fun onFinish() {}
        }
        timer?.start()
    }

    private fun updateTimerDisplay(elapsed: Long) {
        val hours = elapsed / 3600000
        val minutes = (elapsed % 3600000) / 60000
        val seconds = (elapsed % 60000) / 1000

        binding.tvTimer.text = String.format("%02d:%02d:%02d", hours, minutes, seconds)

        // Update progress bar (max 8 jam)
        val progress = (elapsed / 28800000f * 100).toInt().coerceAtMost(100)
        binding.progressTimer.progress = progress
    }

    private fun updateCostEstimate(elapsed: Long) {
        val cost = parkingViewModel.calculateCost(elapsed, vehicleType)
        binding.tvCostEstimate.text = "Estimasi: Rp ${NumberFormat.getInstance().format(cost)}"
    }

    private fun setupClickListeners() {
        binding.btnFinishParking.setOnClickListener {
            showFinishConfirmation()
        }

        binding.btnPauseTimer.setOnClickListener {
            togglePauseTimer()
        }

        binding.btnSaveSession.setOnClickListener {
            saveAndExit()
        }

        binding.btnBack.setOnClickListener {
            showExitConfirmation()
        }
    }

    private fun togglePauseTimer() {
        isPaused = !isPaused
        binding.btnPauseTimer.text = if (isPaused) "LANJUTKAN" else "JEDA"
        saveActiveSession() // Save state saat pause/resume
    }

    private fun saveAndExit() {
        saveActiveSession()
        
        // Simpan ke database sebagai parkir aktif
        val currentTime = System.currentTimeMillis()
        val currentDuration = currentTime - startTime
        val currentCost = parkingViewModel.calculateCost(currentDuration, vehicleType)
        
        val activeParkingRecord = ParkingEntity(
            plateNumber = plateNumber,
            vehicleType = vehicleType,
            startTime = startTime,
            endTime = currentTime,  // Temporary, akan diupdate saat selesai
            duration = currentDuration,
            cost = currentCost,
            isActive = true  // Tandai sebagai masih aktif
        )
        
        parkingViewModel.insertParkingRecord(activeParkingRecord)
        
        MaterialAlertDialogBuilder(this)
            .setTitle("Sesi Disimpan")
            .setMessage("Parkir disimpan ke riwayat. Timer tetap berjalan sampai Anda klik SELESAI di riwayat.")
            .setPositiveButton("OK") { _, _ -> 
                // Kembali ke MainActivity
                val intent = Intent(this, MainActivity::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
                startActivity(intent)
                finish()
            }
            .show()
    }

    private fun showFinishConfirmation() {
        MaterialAlertDialogBuilder(this)
            .setTitle("Selesai Parkir")
            .setMessage("Apakah Anda yakin ingin menyelesaikan parkir?")
            .setPositiveButton("Ya") { _, _ -> finishParking() }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun finishParking() {
        timer?.cancel()
        val endTime = System.currentTimeMillis()
        val duration = endTime - startTime
        val cost = parkingViewModel.calculateCost(duration, vehicleType)

        // Clear active session
        clearActiveSession()

        // Save to database
        val parkingRecord = ParkingEntity(
            plateNumber = plateNumber,
            vehicleType = vehicleType,
            startTime = startTime,
            endTime = endTime,
            duration = duration,
            cost = cost,
            isActive = false  // Parkir sudah selesai
        )

        parkingViewModel.insertParkingRecord(parkingRecord)

        // Show result
        showParkingResult(duration, cost)
    }

    private fun showParkingResult(duration: Long, cost: Int) {
        val intent = Intent(this, ResultActivity::class.java).apply {
            putExtra("plate_number", plateNumber)
            putExtra("vehicle_type", vehicleType)
            putExtra("start_time", startTime)
            putExtra("end_time", System.currentTimeMillis())
            putExtra("duration", duration)
            putExtra("cost", cost)
        }
        startActivity(intent)
        finish()
    }

    private fun createNotificationChannel() {
        val name = "Parking Channel"
        val descriptionText = "Notification for parking reminders"
        val importance = NotificationManager.IMPORTANCE_DEFAULT
        val channel = NotificationChannel("parking_channel", name, importance).apply {
            description = descriptionText
        }

        val notificationManager: NotificationManager =
            getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.createNotificationChannel(channel)
    }

    private fun scheduleNotification() {
        // Notifikasi setelah 1 jam
        Handler(Looper.getMainLooper()).postDelayed({
            showParkingReminder()
        }, 3600000) // 1 jam
    }

    private fun showParkingReminder() {
        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        val notification = NotificationCompat.Builder(this, "parking_channel")
            .setSmallIcon(R.drawable.ic_parking)
            .setContentTitle("Pengingat Parkir")
            .setContentText("Anda sudah parkir lebih dari 1 jam")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .build()

        notificationManager.notify(1, notification)
    }

    private fun formatTime(timestamp: Long): String {
        return SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date(timestamp))
    }

    private fun showExitConfirmation() {
        MaterialAlertDialogBuilder(this)
            .setTitle("Keluar")
            .setMessage("Sesi parkir akan disimpan dan timer tetap berjalan. Lanjutkan?")
            .setPositiveButton("Simpan & Keluar") { _, _ -> 
                saveActiveSession()
                val intent = Intent(this, MainActivity::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
                startActivity(intent)
                finish() 
            }
            .setNegativeButton("Batal", null)
            .show()
    }
    
    private fun applyThemeFromSettings() {
        val prefs = getSharedPreferences("parking_settings", MODE_PRIVATE)
        val themeMode = prefs.getString("theme_mode", "system") ?: "system"
        when(themeMode) {
            "light" -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
            "dark" -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
            else -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        // Jangan cancel timer jika masih ada sesi aktif
        // timer?.cancel()
    }
}
