package com.smartparking.timer.ui

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.smartparking.timer.databinding.ActivityResultBinding
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*

class ResultActivity : AppCompatActivity() {
    private lateinit var binding: ActivityResultBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityResultBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupUI()
        setupClickListeners()
    }

    private fun setupUI() {
        val plateNumber = intent.getStringExtra("plate_number") ?: ""
        val vehicleType = intent.getStringExtra("vehicle_type") ?: ""
        val startTime = intent.getLongExtra("start_time", 0)
        val endTime = intent.getLongExtra("end_time", 0)
        val duration = intent.getLongExtra("duration", 0)
        val cost = intent.getIntExtra("cost", 0)
        val fromHistory = intent.getBooleanExtra("from_history", false)

        binding.apply {
            tvPlateNumber.text = plateNumber
            tvVehicleType.text = vehicleType
            tvStartTime.text = formatTime(startTime)
            tvEndTime.text = formatTime(endTime)
            tvDuration.text = formatDuration(duration)
            tvTotalCost.text = "Rp ${NumberFormat.getInstance().format(cost)}"

            if (fromHistory) {
                btnBackToHome.text = "KEMBALI"
                tvTitle.text = "Detail Parkir"
            }
        }
    }

    private fun setupClickListeners() {
        binding.btnBackToHome.setOnClickListener {
            val fromHistory = intent.getBooleanExtra("from_history", false)
            if (fromHistory) {
                finish()
            } else {
                val intent = Intent(this, MainActivity::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
                startActivity(intent)
                finish()
            }
        }

        binding.btnViewHistory.setOnClickListener {
            startActivity(Intent(this, HistoryActivity::class.java))
        }

        binding.btnShareResult.setOnClickListener {
            shareResult()
        }
    }

    private fun shareResult() {
        val plateNumber = intent.getStringExtra("plate_number") ?: ""
        val vehicleType = intent.getStringExtra("vehicle_type") ?: ""
        val startTime = intent.getLongExtra("start_time", 0)
        val endTime = intent.getLongExtra("end_time", 0)
        val duration = intent.getLongExtra("duration", 0)
        val cost = intent.getIntExtra("cost", 0)

        val shareText = """
            🚗 Smart Parking Timer
            
            Plat: $plateNumber
            Jenis: $vehicleType
            Masuk: ${formatTime(startTime)}
            Keluar: ${formatTime(endTime)}
            Durasi: ${formatDuration(duration)}
            Total: Rp ${NumberFormat.getInstance().format(cost)}
        """.trimIndent()

        val shareIntent = Intent().apply {
            action = Intent.ACTION_SEND
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, shareText)
        }
        startActivity(Intent.createChooser(shareIntent, "Bagikan hasil parkir"))
    }

    private fun formatTime(timestamp: Long): String {
        return SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.getDefault()).format(Date(timestamp))
    }

    private fun formatDuration(duration: Long): String {
        val hours = duration / 3600000
        val minutes = (duration % 3600000) / 60000
        val seconds = (duration % 60000) / 1000
        return String.format("%02d:%02d:%02d", hours, minutes, seconds)
    }
}
