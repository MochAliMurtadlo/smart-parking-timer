package com.smartparking.timer.repository

import androidx.lifecycle.LiveData
import com.smartparking.timer.data.ParkingDao
import com.smartparking.timer.data.ParkingEntity

class ParkingRepository(private val parkingDao: ParkingDao) {

    fun getAllParkingRecords(): LiveData<List<ParkingEntity>> {
        return parkingDao.getAllParkingRecords()
    }

    suspend fun insertParkingRecord(parking: ParkingEntity) {
        parkingDao.insertParkingRecord(parking)
    }

    suspend fun updateParkingRecord(parking: ParkingEntity) {
        parkingDao.updateParkingRecord(parking)
    }

    suspend fun deleteParkingRecord(parking: ParkingEntity) {
        parkingDao.deleteParkingRecord(parking)
    }

    suspend fun deleteAllRecords() {
        parkingDao.deleteAllRecords()
    }

    suspend fun getRecordCount(): Int {
        return parkingDao.getRecordCount()
    }

    suspend fun getParkingById(id: Long): ParkingEntity? {
        return parkingDao.getParkingById(id)
    }
}
