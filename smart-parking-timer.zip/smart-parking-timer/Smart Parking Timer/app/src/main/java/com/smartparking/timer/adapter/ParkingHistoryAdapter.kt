package com.smartparking.timer.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.smartparking.timer.R
import com.smartparking.timer.data.ParkingEntity
import com.smartparking.timer.databinding.ItemParkingHistoryBinding
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*

class ParkingHistoryAdapter(
    private val onItemClick: (ParkingEntity) -> Unit,
    private val onDeleteClick: (ParkingEntity) -> Unit,
    private val onFinishClick: (ParkingEntity) -> Unit = {},
    private val onContinueClick: (ParkingEntity) -> Unit = {}
) : ListAdapter<ParkingEntity, ParkingHistoryAdapter.ViewHolder>(DiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemParkingHistoryBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class ViewHolder(
        private val binding: ItemParkingHistoryBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        init {
            binding.root.setOnClickListener {
                onItemClick(getItem(bindingAdapterPosition))
            }
            binding.btnDelete.setOnClickListener {
                onDeleteClick(getItem(bindingAdapterPosition))
            }
            binding.btnFinishActive.setOnClickListener {
                onFinishClick(getItem(bindingAdapterPosition))
            }
            binding.btnContinueActive.setOnClickListener {
                onContinueClick(getItem(bindingAdapterPosition))
            }
        }

        fun bind(parking: ParkingEntity) {
            binding.apply {
                tvPlateNumber.text = parking.plateNumber
                tvVehicleType.text = parking.vehicleType
                tvDate.text = formatDate(parking.startTime)
                
                // Jika parkir masih aktif, hitung durasi real-time
                val currentDuration = if (parking.isActive) {
                    System.currentTimeMillis() - parking.startTime
                } else {
                    parking.duration
                }
                tvDuration.text = formatDuration(currentDuration)
                tvCost.text = "Rp ${NumberFormat.getInstance().format(parking.cost)}"

                // Set icon berdasarkan jenis kendaraan
                val iconRes = if (parking.vehicleType == "Motor")
                    R.drawable.ic_motorcycle else R.drawable.ic_car
                ivVehicleIcon.setImageResource(iconRes)
                
                // Tampilkan tombol hanya untuk parking yang masih aktif
                if (parking.isActive) {
                    layoutActiveButtons.visibility = View.VISIBLE
                    btnDelete.visibility = View.GONE
                    tvActiveIndicator.visibility = View.VISIBLE
                } else {
                    layoutActiveButtons.visibility = View.GONE
                    btnDelete.visibility = View.VISIBLE
                    tvActiveIndicator.visibility = View.GONE
                }
            }
        }

        private fun formatDate(timestamp: Long): String {
            return SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
                .format(Date(timestamp))
        }

        private fun formatDuration(duration: Long): String {
            val hours = duration / 3600000
            val minutes = (duration % 3600000) / 60000
            return "${hours}j ${minutes}m"
        }
    }

    class DiffCallback : DiffUtil.ItemCallback<ParkingEntity>() {
        override fun areItemsTheSame(oldItem: ParkingEntity, newItem: ParkingEntity): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: ParkingEntity, newItem: ParkingEntity): Boolean {
            return oldItem == newItem
        }
    }
}
