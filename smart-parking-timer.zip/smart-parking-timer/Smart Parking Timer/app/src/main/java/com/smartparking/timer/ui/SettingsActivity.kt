package com.smartparking.timer.ui

import android.content.SharedPreferences
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.smartparking.timer.databinding.ActivitySettingsBinding

class SettingsActivity : AppCompatActivity() {
    private lateinit var binding: ActivitySettingsBinding
    private lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        // Apply tema sebelum setContentView
        sharedPreferences = getSharedPreferences("parking_settings", MODE_PRIVATE)
        val themeMode = sharedPreferences.getString("theme_mode", "system") ?: "system"
        applyTheme(themeMode)
        
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupToolbar()
        setupUI()
        setupClickListeners()
    }

    private fun setupToolbar() {
        try {
            setSupportActionBar(binding.toolbar)
            supportActionBar?.apply {
                title = "Pengaturan"
                setDisplayHomeAsUpEnabled(true)
            }
        } catch (e: Exception) {
            // Jika error, set title manual
            binding.toolbar.title = "Pengaturan"
            binding.toolbar.setNavigationOnClickListener {
                onBackPressedDispatcher.onBackPressed()
            }
        }
    }

    private fun setupUI() {
        // Load saved settings
        val motorRate = sharedPreferences.getInt("motor_rate", 2000)
        val carRate = sharedPreferences.getInt("car_rate", 5000)
        val notificationEnabled = sharedPreferences.getBoolean("notification_enabled", true)
        val soundEnabled = sharedPreferences.getBoolean("sound_enabled", true)
        val autoStopTimer = sharedPreferences.getInt("auto_stop_timer", 0)
        val themeMode = sharedPreferences.getString("theme_mode", "system") ?: "system"

        binding.apply {
            etMotorRate.setText(motorRate.toString())
            etCarRate.setText(carRate.toString())
            switchNotification.isChecked = notificationEnabled
            
            // Set fitur tambahan jika view ada
            try { switchSound.isChecked = soundEnabled } catch (e: Exception) {}
            try { etAutoStopTimer.setText(autoStopTimer.toString()) } catch (e: Exception) {}
            
            // Setup theme spinner jika ada
            try {
                val themes = arrayOf("Sistem", "Terang", "Gelap")
                val adapter = ArrayAdapter(this@SettingsActivity, android.R.layout.simple_spinner_dropdown_item, themes)
                spinnerTheme.adapter = adapter
                spinnerTheme.setSelection(when(themeMode) {
                    "light" -> 1
                    "dark" -> 2
                    else -> 0
                })
            } catch (e: Exception) {}
        }
    }

    private fun setupClickListeners() {
        binding.btnSaveSettings.setOnClickListener {
            saveSettings()
        }

        binding.btnResetSettings.setOnClickListener {
            resetSettings()
        }

        // About button jika ada
        try {
            binding.btnAbout.setOnClickListener {
                showAboutDialog()
            }
        } catch (e: Exception) {}
    }

    private fun saveSettings() {
        val motorRate = binding.etMotorRate.text.toString().toIntOrNull()
        val carRate = binding.etCarRate.text.toString().toIntOrNull()
        var autoStopTimer = 0
        try { autoStopTimer = binding.etAutoStopTimer.text.toString().toIntOrNull() ?: 0 } catch (e: Exception) {}

        if (motorRate == null || carRate == null) {
            Toast.makeText(this, "Masukkan tarif yang valid", Toast.LENGTH_SHORT).show()
            return
        }

        if (motorRate < 1000 || carRate < 1000) {
            Toast.makeText(this, "Tarif minimal Rp 1.000", Toast.LENGTH_SHORT).show()
            return
        }

        var themeMode = "system"
        try {
            themeMode = when(binding.spinnerTheme.selectedItemPosition) {
                1 -> "light"
                2 -> "dark"
                else -> "system"
            }
        } catch (e: Exception) {}

        var soundEnabled = true
        try { soundEnabled = binding.switchSound.isChecked } catch (e: Exception) {}

        sharedPreferences.edit().apply {
            putInt("motor_rate", motorRate)
            putInt("car_rate", carRate)
            putBoolean("notification_enabled", binding.switchNotification.isChecked)
            putBoolean("sound_enabled", soundEnabled)
            putInt("auto_stop_timer", autoStopTimer)
            putString("theme_mode", themeMode)
            apply()
        }

        // Apply theme immediately
        applyTheme(themeMode)

        Toast.makeText(this, "Pengaturan berhasil disimpan", Toast.LENGTH_SHORT).show()
        finish()
    }

    private fun resetSettings() {
        binding.apply {
            etMotorRate.setText("2000")
            etCarRate.setText("5000")
            switchNotification.isChecked = true
            try { switchSound.isChecked = true } catch (e: Exception) {}
            try { etAutoStopTimer.setText("0") } catch (e: Exception) {}
            try { spinnerTheme.setSelection(0) } catch (e: Exception) {}
        }
        Toast.makeText(this, "Pengaturan direset ke default", Toast.LENGTH_SHORT).show()
    }

    private fun applyTheme(themeMode: String) {
        when(themeMode) {
            "light" -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
            "dark" -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
            else -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
        }
    }

    private fun showAboutDialog() {
        MaterialAlertDialogBuilder(this)
            .setTitle("Tentang Aplikasi")
            .setMessage(
                "Smart Parking Timer v1.0\n\n" +
                "Aplikasi untuk mengelola parkir kendaraan dengan mudah.\n\n" +
                "Fitur:\n" +
                "• Timer parkir otomatis\n" +
                "• Perhitungan biaya parkir\n" +
                "• Riwayat parkir lengkap\n" +
                "• Export data ke CSV\n" +
                "• Pengaturan tarif custom\n\n" +
                "© 2026 Smart Parking Timer"
            )
            .setPositiveButton("OK", null)
            .show()
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressedDispatcher.onBackPressed()
        return true
    }
}
