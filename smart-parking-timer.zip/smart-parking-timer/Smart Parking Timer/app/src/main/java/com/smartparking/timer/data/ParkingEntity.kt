package com.smartparking.timer.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "parking_records")
data class ParkingEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val plateNumber: String,
    val vehicleType: String,
    val startTime: Long,
    val endTime: Long,
    val duration: Long,
    val cost: Int,
    val location: String = "",
    val isActive: Boolean = false  // true jika parkir masih berjalan
)
