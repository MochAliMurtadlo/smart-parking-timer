package com.smartparking.timer.ui

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.ArrayAdapter
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.lifecycle.ViewModelProvider
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.smartparking.timer.R
import com.smartparking.timer.databinding.ActivityMainBinding
import com.smartparking.timer.viewmodel.ParkingViewModel
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var parkingViewModel: ParkingViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        // Apply tema sebelum setContentView
        applyThemeFromSettings()
        
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        parkingViewModel = ViewModelProvider(this)[ParkingViewModel::class.java]

        // Check if there's an active parking session
        checkActiveSession()

        setupUI()
        setupClickListeners()
        observeData()
    }

    private fun applyThemeFromSettings() {
        val prefs = getSharedPreferences("parking_settings", MODE_PRIVATE)
        val themeMode = prefs.getString("theme_mode", "system") ?: "system"
        when(themeMode) {
            "light" -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
            "dark" -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
            else -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
        }
    }

    private fun checkActiveSession() {
        val prefs = getSharedPreferences("parking_session", MODE_PRIVATE)
        val hasActiveSession = prefs.getBoolean("has_active_session", false)
        
        if (hasActiveSession) {
            // Show dialog untuk melanjutkan sesi
            MaterialAlertDialogBuilder(this)
                .setTitle("Sesi Parkir Aktif")
                .setMessage("Anda memiliki sesi parkir yang masih berjalan. Lanjutkan?")
                .setPositiveButton("Lanjutkan") { _, _ ->
                    val intent = Intent(this, TimerActivity::class.java)
                    startActivity(intent)
                }
                .setNegativeButton("Batalkan Sesi") { _, _ ->
                    prefs.edit().clear().apply()
                }
                .setCancelable(false)
                .show()
        }
    }

    private fun setupUI() {
        // Setup spinner untuk jenis kendaraan
        val vehicleTypes = arrayOf("Motor", "Mobil")
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, vehicleTypes)
        binding.spinnerVehicleType.adapter = adapter

        // Setup current time
        updateCurrentTime()
    }

    private fun setupClickListeners() {
        binding.btnStartParking.setOnClickListener {
            val plateNumber = binding.etPlateNumber.text.toString().trim()
            val vehicleType = binding.spinnerVehicleType.selectedItem.toString()

            if (validateInput(plateNumber)) {
                startParking(plateNumber, vehicleType)
            }
        }

        binding.btnViewHistory.setOnClickListener {
            startActivity(Intent(this, HistoryActivity::class.java))
        }

        binding.btnSettings.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
    }

    private fun validateInput(plateNumber: String): Boolean {
        if (plateNumber.isEmpty()) {
            binding.tilPlateNumber.error = "Plat nomor tidak boleh kosong"
            return false
        }
        if (plateNumber.length < 3) {
            binding.tilPlateNumber.error = "Plat nomor minimal 3 karakter"
            return false
        }
        binding.tilPlateNumber.error = null
        return true
    }

    private fun startParking(plateNumber: String, vehicleType: String) {
        val intent = Intent(this, TimerActivity::class.java).apply {
            putExtra("plate_number", plateNumber.uppercase())
            putExtra("vehicle_type", vehicleType)
            putExtra("start_time", System.currentTimeMillis())
        }
        startActivity(intent)
    }

    private fun updateCurrentTime() {
        val handler = Handler(Looper.getMainLooper())
        val runnable = object : Runnable {
            override fun run() {
                val currentTime = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
                    .format(Date())
                binding.tvCurrentTime.text = "Waktu: $currentTime"
                handler.postDelayed(this, 1000)
            }
        }
        handler.post(runnable)
    }

    private fun observeData() {
        parkingViewModel.allParkingRecords.observe(this) { records ->
            binding.tvTotalRecords.text = "Total Riwayat: ${records.size}"
        }
    }
}
